package oopbusmanagementsystem;

import java.io.Serializable;

public class Economy extends Bus implements Serializable{
    
    // This is the basic price of a economy class bus
    
    private final int price = 250;
    private static int counterEconomy = 0;
    
    public Economy(String busId1, Route bus_route1, CompanyInventory inv1){
        
        super(busId1, bus_route1, inv1);
        counterEconomy++;
        counterBus++;
    }
    
    // These are getter methods which will provide details regarding economy type 
    
    public static void getNumberOfBuses(){
        
        System.out.println("The economy type of buses are " + counterEconomy);
    }
    @Override
    public int get_price(){
        
        return price;
    }

    @Override
    public String get_type() {
        
        return("Economy");
    }
    @Override
    public void display(){
        
        System.out.println("Id is : " + this.busId + " || Bus is of type " + this.get_type() 
                + " || Its route is" + bus_route.toString() 
                + " || Its basic ticket price is " + this.price);
    }
}
