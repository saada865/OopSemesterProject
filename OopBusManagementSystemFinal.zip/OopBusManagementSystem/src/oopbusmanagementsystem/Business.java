package oopbusmanagementsystem;

import java.io.Serializable;

    public class Business extends Bus implements Serializable{
    
    // This is the basic price of a business class bus
        
    private final int price = 500;
    private static int counterBusiness = 0;
    
    
    public Business(String busId1, Route bus_route1, CompanyInventory inv1){
        
        super(busId1, bus_route1, inv1);
        counterBusiness++;
        counterBus++;
    }
    
    // These are getter methods which will provide details regarding business type 
    
    public static void getNumberOfBuses(){
        
        System.out.println("The business type of buses are " + counterBusiness);
    }

    
    @Override
    public int get_price(){
        
        return price;
    }

    @Override
    public String get_type() {
        
        return("Business");
    }
    
    @Override
    public void display(){
        
        System.out.println("Id is : " + this.busId + " || Bus is of type " + this.get_type() 
                + " || Its route is" + bus_route.toString() 
                + " || Its basic ticket price is " + this.price);
    }
    
}

