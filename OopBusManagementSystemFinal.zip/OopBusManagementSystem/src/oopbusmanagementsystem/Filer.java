package oopbusmanagementsystem;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Filer implements Serializable{

    // This method will write data on to the file
    
    public void filingWrite(ArrayList<Bus> testObj){
    File f1 = new File("MyFile2.txt");
    try{
    FileOutputStream fout = new FileOutputStream(f1);
    ObjectOutputStream oos = new ObjectOutputStream(fout);
    oos.writeObject(testObj);
    f1.exists();
    oos.close();
    fout.close();
    }
    catch(FileNotFoundException io){
    io.printStackTrace();
    }
    catch(IOException io){
    io.printStackTrace();

    }
    }   
    
    // This method will update netbeans data by returning the file version of the arraylist holding buses
    
    public ArrayList<Bus> filingRead2(){
       File f1 = new File("MyFile2.txt");
        
    ArrayList<Bus> c = null;
    try{
    FileInputStream fin = new FileInputStream(f1); 
    ObjectInputStream ois = new ObjectInputStream(fin);
    
    c = (ArrayList)ois.readObject();
    ois.close();
    fin.close();
    
    }
    catch(FileNotFoundException io){
        io.printStackTrace();
    }
    catch(IOException io){
        io.printStackTrace();
    }
    catch(ClassNotFoundException io){
        io.printStackTrace();
    }
    return c;}
    
    // This method will read and display buses and their data
    
    public void filingRead(){
        File f1 = new File("MyFile2.txt");
    
    try{
    FileInputStream fin = new FileInputStream(f1); 
    ObjectInputStream ois = new ObjectInputStream(fin);
    ArrayList<Bus> c;
    c = (ArrayList)ois.readObject();
    
    ois.close();
    fin.close();
    for(Bus x: c){
    
        System.out.println(x);
    }
    }  
    catch(FileNotFoundException io){
        io.printStackTrace();
    }
    catch(IOException io){
        io.printStackTrace();
    }
    catch(ClassNotFoundException io){
        io.printStackTrace();
    }
    }
}
