package oopbusmanagementsystem;

    public interface RouteFares<T> {
    
    // This interface houses the route prices for various routes on the basis of distance
    // These will be used to calculate route fare and finally the bill
        
    public static final int LAHORETOKARACHI = 3000, LAHORETOISLAMABAD = 500, LAHORETOFAISALABAD = 300, LAHORETOPESHAWAR = 700;
    public static final int KARACHITOLAHORE = 3000, KARACHITOISLAMABAD = 3500, KARACHITOFAISALABAD = 2700, KARACHITOPESHAWAR = 3700;
    public static final int ISLAMABADTOLAHORE = 500, ISLAMABADTOKARACHI = 3500, ISLAMABADTOFAISALABAD = 400, ISLAMABADTOPESHAWAR = 200;
    public static final int FAISALABADTOLAHORE = 300, FAISALABADTOKARACHI = 2700, FAISALABADTOISLAMABAD = 400, FAISALABADTOPESHAWAR = 600;
    public static final int PESHAWARTOLAHORE = 700, PESHAWARTOKARACHI = 3700, PESHAWARTOISLAMABAD = 200, PESHAWARTOFAISALABAD = 600;
   
    public int calc(T o);
}

