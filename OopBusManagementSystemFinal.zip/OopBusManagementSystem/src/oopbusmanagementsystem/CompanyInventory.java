package oopbusmanagementsystem;

import java.io.Serializable;
import java.util.ArrayList;

    public class CompanyInventory implements Serializable{

    ArrayList<Bus> inventoryCI = new ArrayList<>();
    protected Filer filed = new Filer(); 
    public CompanyInventory(){
       
    imp();
    }
    
    // This method will update the data in netbeans by taking data from the file
    
    public void imp(){
        inventoryCI = filed.filingRead2();
    }
    
    // This method will update file data
    
    public void handler(){
        
        filed.filingWrite(inventoryCI);
    }
    public void add(Bus bus){
        
        inventoryCI.add(bus);
        handler();
    }
    public void remove(Bus bus){
        
        int r = inventoryCI.indexOf(bus);
        
        System.out.println("Bus : " + bus.get_id()+ " has been removed");
        inventoryCI.remove(r);
        handler();
    }
    
    // This method will search and return a bus based on id 
    
    Bus search(String id){
        
        int iter = -1;
        
        for(Bus x: inventoryCI){
            
            iter++;
            if(id.equals(x.busId)){
                
        return inventoryCI.get(iter);
            }
            else{
                continue;
            }
            
        }
        
        return null;
    }
    
    // This method checks to see if the given id actually exists or not
    
    public int search2(String id){
        int iter = -1;
        
        for(Bus x: inventoryCI){
            
            iter++;
            if(id.equals(x.busId)){
                
        return 1;
            }
            else{
                continue;
            }
            
        }
        
        return 0;
    }
    
    // This method will delete a single bus  
    
    public void deleteSingle(String id){
        
        Bus objD = search(id);
        if(objD == null){
            return;
        }
        inventoryCI.remove(objD);
        handler();
    }
    
    // This method will delete all buses 
    
    public void deleteAll(){
        
        inventoryCI.clear();
        handler();
    }
    
    // This method will display all the contents of the array passed to it which will be the bus array
    
    public static<T> void display(T[] arrayL){
        
        for(T element: arrayL){
            
     System.out.println(element);
        }
        
    }
    @Override
    public String toString(){
        
        for(Bus x: inventoryCI){
            
        System.out.println(x.toString());
        
        }
        return null;
    }
            
     
}
