package oopbusmanagementsystem;

import java.io.Serializable;

    public class Seats implements Serializable{
    
    // This class houses the seats of one bus and performs many operations on them
        
    private int totalSeats = 11;
    private int counter = 0;
    
    public void addSeats(){
        
        this.counter += 1;
    }
    public void removeSeats(){
        
        this.counter -= 1;
    }
    public void seatsOccupiedStr(){
        
        System.out.println("Seats booked are : " + counter);
    }
    public int seatsOccupiedInt(){
        
        return counter;
    }
    public void seatsFreeStr(){
        
        int r = this.totalSeats - counter;
        System.out.println("Seats free are : " + r);
    }
    public int seatsFreeInt(){
        
        int r = this.totalSeats - counter;
        return r;
    }
    
    
}
