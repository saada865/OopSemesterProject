package oopbusmanagementsystem;

import java.io.Serializable;

    // This class sets the route

    public class Route implements Serializable{

    private String from;
    private String to;
    
    public Route(){
        
    }
    public Route(String from, String to){
        
        this.from =  from;
        this.to = to;
    }
    public String get_from(){
        
        return this.from;
    }
    public String get_to(){
        
        return this.to;
    }
    public void set_from(String from1){
        
        this.from = from1;
    }
    public void set_to(String to1){
        
        this.to = to1;
    }
    @Override
    public String toString(){
        
        return(" | Departure city : " + this.from + " , Arrival city : " + this.to);
    }
        
}


