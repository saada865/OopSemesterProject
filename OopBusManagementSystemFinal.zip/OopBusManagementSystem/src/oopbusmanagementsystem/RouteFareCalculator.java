package oopbusmanagementsystem;

import java.io.Serializable;

    // This class calculates the route fare of any route

    public class RouteFareCalculator implements Serializable, RouteFares<Route>{
    
    private int val;
    
    @Override
    
    // This method will according to the cities assign fare by picking it from the RouteFares Interface
    
    public int calc(Route route){
        
        String from = route.get_from();
        String to = route.get_to();
        
        switch(from){
        
            case "Lahore":{
        if(to.equals("Karachi")){
            
            val = LAHORETOKARACHI;
            break;
        }
        if(to.equals("Islamabad")){
            
            val = LAHORETOISLAMABAD;
            break;
        }
        if(to.equals("Faisalabad")){
            
            val = LAHORETOFAISALABAD;
            break;
        }
        if(to.equals("Peshawar")){
            
            val = LAHORETOPESHAWAR;
            break;
        }
            }
    
            case "Karachi":{
        if(to.equals("Lahore")){
            
            val = KARACHITOLAHORE;
            break;
        }
        if(to.equals("Islamabad")){
            
            val = KARACHITOISLAMABAD;
            break;
        }
        if(to.equals("Peshawar")){
            
            val = KARACHITOPESHAWAR;
            break;
        }
        if(to.equals("Faisalabad")){
            
            val = KARACHITOFAISALABAD;
            break;
        }
            }
        case "Islamabad":{
        if(to.equals("Lahore")){
            
            val = ISLAMABADTOLAHORE;
            break;
        }
        if(to.equals("Karachi")){
            
            val = ISLAMABADTOKARACHI;
            break;
        }
        if(to.equals("Peshawar")){
            
            val = ISLAMABADTOPESHAWAR;
            break;
        }
        if(to.equals("Faisalabad")){
            
            val = ISLAMABADTOFAISALABAD;
            break;
        }
            }
        
        case "Faisalabad":{
        if(to.equals("Lahore")){
            
            val = FAISALABADTOLAHORE;
            break;
        }
        if(to.equals("Karachi")){
            
            val = FAISALABADTOKARACHI;
            break;
        }
        if(to.equals("Peshawar")){
            
            val = FAISALABADTOPESHAWAR;
            break;
        }
        if(to.equals("Islamabad")){
            
            val = FAISALABADTOISLAMABAD;
            break;
        }
            }
        
        case "Peshawar":{
        if(to.equals("Lahore")){
            
            val = PESHAWARTOLAHORE;
            break;
        }
        if(to.equals("Karachi")){
            
            val = PESHAWARTOKARACHI;
            break;
        }
        if(to.equals("Faisalabad")){
            
            val = PESHAWARTOFAISALABAD;
            break;
        }
        if(to.equals("Islamabad")){
            
            val = PESHAWARTOISLAMABAD;
            break;
        }
            }
        
        
        }
        
        
        return val;
        
        }
    
}
