package oopbusmanagementsystem;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class OopBusManagementSystem {
    
    static Scanner input = new Scanner(System.in);
        
    public static void main(String[] args)  {
        
        // Initializing the Companyinventory class which houses all the buses
        // Initializing the Filer class
        // Initializing the Biller class which calculates bills
        
        CompanyInventory comInt = new CompanyInventory();
        Filer filed = new Filer();
        Biller billed = new Biller();
        
        System.out.println("\t\t\t\t\t\t|||******************************|||");
            System.out.println("\t\t\t\t\t\t**Welcome to Bus Management System**");
            System.out.println("\t\t\t\t\t\t|||******************************|||");
            System.out.println();
        
        int opt1;
        int opt11;
        int opt111;
        int opt12;
        int opt121;
        while(true){
            
            // Options to either access the manager portal or the customer portal
            // If you press an invalid key then you will be asked to do so again
            
            System.out.println("Press 1 for manager portal || Press 2 for customer portal || Press 0 to exit");
            System.out.println();
            opt1 = Catcher();
        
            if(opt1 == 1){
                while(true){
                    
                    // Options to perform various functions in the manager portal
                    
                    
               System.out.println("Press 1 to view records || Press 2 to delete All records || "
                       + "Press 3 for total revenue of a bus ");
               System.out.println(" || Press 4 to remove a single bus || Press 5 to Add a new bus ||"
                       + " Press 0 to exit "); 
               System.out.println();
               
               // The options will be taken in the Catcher so if a string or other ivalid data is entered 
               // you are asked to enter again
               // This and such checks are implemented all through the program 
               
               opt11 = Catcher();
               if(opt11 == 1){
                   
                   // All the file data regarding the buses will be printed
                   
                   System.out.println();
                   filed.filingRead();
                   System.out.println();
                }
               else if(opt11 == 2){
                
                   // All the file data will be deleted 
                   
                comInt.deleteAll();
                filed.filingRead();
                System.out.println();
                System.out.println("All Deleted");
                System.out.println();
                }
               else if(opt11 == 3){
                   
                   // All the revenue of any specific bus will be given if their is no such bus then you will be 
                   // taken back to the menu
                   
                   System.out.println();
                   System.out.println("Enter in id of bus");
                   System.out.println();
                    String busid4 = input.next();
                    if(comInt.search2(busid4) == 0){
             System.out.println();
             System.out.println("Invalid id");
             System.out.println();
             
                       break;
                   }
                    else{
                    Bus objGrab = comInt.search(busid4);
                    int val = billed.calcBill(objGrab) * objGrab.seats.seatsOccupiedInt();
                    System.out.println();
                    System.out.println("Total revenue of bus is : " + val);
                    System.out.println();
                }
                   
                   
                   
               }
               else if(opt11 == 4){
                   
                   // Any specific bus will be deleted if their is no such bus then you will be 
                   // taken back to the menu
                   
                   System.out.println();
                   System.out.println("Enter in bus id of the bus you want to delete");
                   System.out.println();
                   String busid1 = input.next();
                   if(comInt.search2(busid1) == 0){

             System.out.println("Invalid id");
                       break;
                   }
                   else if(comInt.search2(busid1) == 1){
                   comInt.deleteSingle(busid1);
                   System.out.println();
                   System.out.println("Deleted");
                   System.out.println();
                   }
               }
               else if(opt11 == 5){
                   
                   // Options regarding adding of a new  bus will be given
                   // including their type routes etc
                   
                   System.out.println();
                   System.out.println("Enter in type of bus you want to add Press 1 for Business 2 Economy");
                   System.out.println();
                   opt111 = Catcher();
                   if(opt111 == 1){
                       
                       Route r = new Route();
                       int optHere1;
                       int optHere2;
                       System.out.println();
                       System.out.println("Enter in id of new bus || Such as B1, E1");
                       System.out.println();
                       String id = input.next();
                       
                       // If you enter in an invalid option default cities will be asssinged
                       
                       System.out.println("Enter in departure city of new bus");
                       System.out.println();
                       System.out.println("Enter 1 for Lahore");
                       System.out.println("Enter 2 for Karachi");
                       System.out.println("Enter 3 for Islamabad");
                       System.out.println("Enter 4 for Pehsawar");
                       System.out.println("Enter 5 for Faisalabad");
                       optHere1 = Catcher();
                       switch (optHere1) {
                           case 1:
                               r.set_from("Lahore");
                               break;
                           case 2:
                               r.set_from("Karachi");
                               break;
                           case 3:
                               r.set_from("Islamabad");
                               break;
                           case 4:
                               r.set_from("Peshawar");
                               break;
                           case 5:
                               r.set_from("Faisalabad");
                               break;
                           default:
                               r.set_from("Faisalabad");
                               break;
                       }
                       
                       System.out.println("Enter in arrival city of new bus");
                       System.out.println();
                       System.out.println("Enter 1 for Lahore");
                       System.out.println("Enter 2 for Karachi");
                       System.out.println("Enter 3 for Islamabad");
                       System.out.println("Enter 4 for Pehsawar");
                       System.out.println("Enter 5 for Faisalabad");
                       optHere2 = Catcher();
                       switch (optHere2) {
                           case 1:
                               r.set_to("Lahore");
                               break;
                           case 2:
                               r.set_to("Karachi");
                               break;
                           case 3:
                               r.set_to("Islamabad");
                               break;
                           case 4:
                               r.set_to("Peshawar");
                               break;
                           case 5:
                               r.set_to("Faisalabad");
                               break;
                           default:
                               r.set_to("Peshawar");
                               break;
                       }
                       Business bus = new Business(id, r, comInt);
                       comInt.add(bus);
                       System.out.println();
                       System.out.println("New Bus " + id + " added");
                       System.out.println();
                   }
                   else if(opt111 == 2){
                       int optHere1;
                       int optHere2;
                       Route r = new Route();
                       System.out.println();
                       System.out.println("Enter in id of new bus");
                       System.out.println();
                       String id = input.next();
                       
                       // If you enter in an invalid option default cities will be asssinged
                       
                       System.out.println("Enter in departure city of new bus");
                       System.out.println();
                       System.out.println("Enter 1 for Lahore");
                       System.out.println("Enter 2 for Karachi");
                       System.out.println("Enter 3 for Islamabad");
                       System.out.println("Enter 4 for Pehsawar");
                       System.out.println("Enter 5 for Faisalabad");
                       optHere1 = Catcher();
                       
                       switch (optHere1) {
                           case 1:
                               r.set_from("Lahore");
                               break;
                           case 2:
                               r.set_from("Karachi");
                               break;
                           case 3:
                               r.set_from("Islamabad");
                               break;
                           case 4:
                               r.set_from("Peshawar");
                               break;
                           case 5:
                               r.set_from("Faisalabad");
                               break;
                           default:
                               r.set_from("Faisalabad");
                               break;
                       }
                       
                       
                       System.out.println("Enter in arrival city of new bus");
                       System.out.println();
                       System.out.println("Enter 1 for Lahore");
                       System.out.println("Enter 2 for Karachi");
                       System.out.println("Enter 3 for Islamabad");
                       System.out.println("Enter 4 for Pehsawar");
                       System.out.println("Enter 5 for Faisalabad");
                       optHere2 = Catcher();
                       switch (optHere2) {
                           case 1:
                               r.set_to("Lahore");
                               break;
                           case 2:
                               r.set_to("Karachi");
                               break;
                           case 3:
                               r.set_to("Islamabad");
                               break;
                           case 4:
                               r.set_to("Peshawar");
                               break;
                           case 5:
                               r.set_to("Faisalabad");
                               break;
                           default:
                               r.set_to("Peshawar");
                               break;
                       }
                       Economy bus = new Economy(id, r, comInt);
                       comInt.add(bus);
                       System.out.println();
                       System.out.println("New Bus " + id + " added");
                       System.out.println();
                   }
                   
               }
               else if(opt11 == 0){
                   
                   break;
               }
                }
            }
            else if(opt1 == 2){
                while(true){
                    
                    // Customer menu
                    
                System.out.println("Press 1 to see Buses and Routes || Press 2 to reserve seat || "
                        + "Press 3 to unreserve seat ");
                System.out.println(" || Press 4 to check if space is availible in a bus "
                        + "|| Press 5 to get price of any bus seat || Press 0 to exit");
                System.out.println();
                opt12 = Catcher();
                if(opt12 == 1){
                   System.out.println();
                   filed.filingRead();
                   System.out.println();
                }
                if(opt12 == 2){
                
                    // A seat in any valid bus shall be assigned
                    // if their is no such bus you will be taken back to menu
                    
                   System.out.println();
                   System.out.println("Enter in bus Id");
                   System.out.println();
                   String busid1 = input.next();
                   
                   if(comInt.search2(busid1) == 0){
             System.out.println();
             System.out.println("Invalid id");
             System.out.println();
                   }
                   else if(comInt.search2(busid1) == 1){
                   Bus objGrab = comInt.search(busid1);
                    
                    objGrab.AddSeats();
                    System.out.println();
                    System.out.println("Seat number alloted is : " + objGrab.seats.seatsOccupiedInt());
                    System.out.println();
                    
                    // You can decide to wether see the bill or not
                    
                    System.out.println("Enter in 1 to get bill of the seat you just reserved or 0 to continue");
                    System.out.println();
                    opt121 = Catcher();
                    if(opt121 == 1){
                        
                        System.out.println("Total bill is : " + billed.calcBill(objGrab));
                        
                   objGrab.display();
                   System.out.println();
                    
                   }
                   }
                }
                else if(opt12 == 3){
                    
                    // A seat previously reserved shall be unreserved bus 
                    // if such seat was not reserved then you will be taken back to menu
                    
                    System.out.println();
                    System.out.println("Enter in bus Id");
                    System.out.println();
                    String busid2 = input.next();
                    if(comInt.search2(busid2) == 0){

             System.out.println();
             System.out.println("Invalid id");
             System.out.println();
                   }
                    else{
                    Bus objGrab = comInt.search(busid2);
                    objGrab.RemoveSeats();
                    System.out.println("Unreserved");
                }
                }
                else if(opt12 == 4){
                    
                    // Space will be checked in a bus
                    
                    System.out.println();
                    System.out.println("Enter in bus Id");
                    System.out.println();
                    String busid3 = input.next();
                    if(comInt.search2(busid3) == 0){
             System.out.println();
             System.out.println("Invalid id");
             System.out.println();
                       break;
                   }
                    else{
                    Bus objGrab = comInt.search(busid3);
                    if(objGrab.checkIfSpace()){
                        System.out.println();
                        System.out.println("Yes space is availible");
                        System.out.println("Seats occupied are : " + objGrab.seats.seatsOccupiedInt());
                        System.out.println();
                    }else{
                        System.out.println();
                        System.out.println("No space is not availible");
                        System.out.println();
                    }
                    }
                }
                else if(opt12 == 5){
                    
                    // Bill of any bus seat will be given without actually booking seat
                    
                    System.out.println();
                    System.out.println("Enter in id of bus");
                    System.out.println();
                    String busid4 = input.next();
                    if(comInt.search2(busid4) == 0){
             System.out.println();
             System.out.println("Invalid id");
             System.out.println();
                       break;
                   }
                    else{
                    Bus objGrab = comInt.search(busid4);
                    System.out.println();
                    System.out.println(billed.calcBill(objGrab));
                    System.out.println();
                }
                }
                else if(opt12 == 0){
                    
                    break;
                }
                }
            }
            else if (opt1 == 0){
                
                break;
            }
            
            
        }
        
    }
     public static int Catcher(){
         int y;
         while (true)
   {
   try
   {
       
    y = input.nextInt();
    break;
   }
   
   catch (InputMismatchException e)
   {
       
    System.out.print("Please enter in an integer! ");
    input.next();
   }
   }   
     
    return y;
     }
     
}
