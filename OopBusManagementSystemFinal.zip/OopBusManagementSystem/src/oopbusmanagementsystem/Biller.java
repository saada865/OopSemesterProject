package oopbusmanagementsystem;

import java.io.Serializable;

    public class Biller implements Serializable{
    
        // This class calculates the bill on the basis of route and the bus type
        
    private RouteFareCalculator frc = new RouteFareCalculator();
    private int bill = 0;
    
    public Biller(){
        
    }
    
    public int calcBill(Bus bus1){
        
        
        if(bus1 instanceof Business){
            
            int a = ((Business)bus1).get_price();
            int b = frc.calc(((Business) bus1).get_bus_route());
            bill  = a + b;
        }
        else if(bus1 instanceof Economy){
            
            int d = ((Economy)bus1).get_price();
            int v = frc.calc(((Economy) bus1).get_bus_route());
            bill = d + v;
        }
        
        return bill;
    }
    
}
