package oopbusmanagementsystem;

import java.io.Serializable;

public abstract class Bus implements Serializable{
    
    // This is the parent abstract bus class   
    
    protected CompanyInventory inv;
    protected String busId;
    protected Filer fileInv = new Filer();
    protected Route bus_route;
    protected Seats seats = new Seats();
    protected static int counterBus = 0;
    
    public Bus(){
        
    }
    public Bus(String busId1, Route bus_route1, CompanyInventory inv1){
        
        this.busId = busId1;
        this.bus_route = bus_route1;
        this.inv = inv1;
        counterBus++;
    }
    
    // These are the abstract methods being defined in its children
    
    public abstract String get_type();
    public abstract int get_price();
    
    // These are getter methods which will provide details regarding bus
    
    public static void getNumberOfBuses(){
        
        System.out.println("The total number of buses of all types is " + counterBus);
    } 
    public Route get_bus_route(){
        
        return this.bus_route;
    }
    public String get_id(){
        
        return this.busId;
    }
    
    // These are setter methods which will set details regarding bus
    
    public void set_busId(String busId1){
        
        this.busId = busId1;
    }
    public void set_busRoute(Route bus_route1){
        
        this.bus_route = bus_route1;
    }
    
    // This method will add a single seat by calling seats class method
    
    public void AddSeats(){
        
        this.seats.addSeats();
        
        // This method will write/update file data
        inv.handler();
    }
    
    // This method will remove a single seat by calling seats class method
    
    public void RemoveSeats(){
        
        if(this.seats.seatsFreeInt() == 11){
            System.out.println("Cannot be removed as no seat is booked");
            return;
        }
        this.seats.removeSeats();
        inv.handler();
    }
    public int FreeSeats(){
        
        return this.seats.seatsFreeInt();
    } 
    
    // This method will check to see if space is availible in a bus
    
    public boolean checkIfSpace(){
        
        if(this.seats.seatsFreeInt() == 0){
            
            return false;
        }
        
        return true;
    }
    @Override
    public String toString(){
        
        return("Bus ID : " + this.busId + " / Total seating capacity : " + this.seats.seatsFreeInt() +
                " / Reserved seats : " + this.seats.seatsOccupiedInt()+
                " / Bus route" + bus_route.toString());  
    }
    
   public void display(){
       
       System.out.println("Bus is simple id is : " + this.busId + "Its route is |" + bus_route.toString());
   }    
    
}

